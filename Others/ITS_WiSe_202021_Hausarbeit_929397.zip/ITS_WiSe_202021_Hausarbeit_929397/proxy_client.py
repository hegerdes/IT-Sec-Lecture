import signal
import argparse
import threading
import os
import socket
import struct
import sys
import select
import ssl

SIZE = 256 * 1024

# Verarbeite die Argumente
def dealWithArguments() :
    parser = argparse.ArgumentParser()
    parser.add_argument("-f", help="Path to the configuration file.")
    parser.add_argument("--ca", help="Path to the certificate of the CA")
    parser.add_argument("--certificate", help="location of the certificate of the client")
    parser.add_argument("--key", help="location of the private key of the server")
    args = parser.parse_args()
    
    # Speichere die Argumente in passende globale Variablen
    global configFilePath
    configFilePath = args.f
    
    global pathToCACertificate
    global useTLS
    global context
    global doClientAuth
    global pathToClientCertificate
    global pathToClientPrivateKey
    
    useTLS = False
    pathToCACertificate = args.ca
    
    # Falls Programm mit --ca aufgerufen wird, wird TLS genutzt
    if (pathToCACertificate != None) :
        useTLS = True

    doClientAuth = False
    pathToClientCertificate = args.certificate
    pathToClientPrivateKey = args.key
    
    # Authetifizierung des Clients durch den Server wird gemacht, falls --certificate und --key genutzt werden.
    if (pathToClientCertificate != None and pathToClientPrivateKey != None) :
        doClientAuth = True
    
    # Falls TLS genutzt werden soll, bereite ssl vor.
    context = None

    if useTLS :
        # Nutze ssl als client, d.h. verlangt, dass der server authetifiziert wird
        context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=pathToCACertificate)
        # Falls der Server den Nutzer authetifizieren soll, lade Zertifikat und private Key des Client
        if doClientAuth :
            context.load_cert_chain(certfile=pathToClientCertificate, keyfile=pathToClientPrivateKey)

# Lade die Konfigurationsdatei
def readConfigFile() :
    try :
        # Lade die Konfigurationsdatei und speichere ihren Inhalt zeilenweise in einer Liste
        configFile = open(configFilePath, "r")
        lines = configFile.readlines()
        configFile.close()
    except :
        print("Error when reading configuration file, quitting programm!")
        configFile.close()
        sys.exit()
    # Von jedem Eintrag Leerzeichen vorne und hinten entfernen und Leerzeilen + Kommentarzeilen ausfiltern
    linesTrimmed = [line.strip() for line in lines]
    linesWithoutComments = [line for line in linesTrimmed if (line != "" and line[0] != "#")]
    # Parse die Einträge
    return map(parseConfig, linesWithoutComments)

# Parst die Einträge der Konfigurationsdatei
def parseConfig(config) :
    # Zerlge die Einträge an den ":", entferne Leerzeichen vorne und hinten an jedem Teil
    listOfEntries = [s.strip() for s in config.split(":")]
    
    # Es sollten genau 5 Teile vorhanden sein
    if len(listOfEntries) != 5 :
        print("Error in configuration file!")
        sys.exit()
    
    # Speichere die Teile entsprechend ab, parse die Ports zu ints
    address_di = listOfEntries[0]
    address_s = listOfEntries[2]
    try :
        port_di = int(listOfEntries[1])
        port_x = int(listOfEntries[3])
        port_bypassi = int(listOfEntries[4])
    except socket.error as errorMessage :
        print("Error parsing ports in configuration file: %s" % errorMessage)
        sys.exit()
    
    # Überprüfe die Ports auf Gültigkeit
    if (0 <= port_di and port_di <= 65535 and 0 <= port_x and port_x <= 65535 and 0 <= port_bypassi and port_bypassi <= 65535) :
        return (address_di, port_di, address_s, port_x, port_bypassi)
    else :
        print("Some ports in the configuration file are not in a valid range")
        sys.exit()

# Funktion für die Threads
def clientInstance(config) :
    # Schreibe die Einträge der Konfigurationsdatei in passende Variablen
    (address_di, port_di, address_s, port_x, port_bypassi) = config
    #print("Open Listening Socket") # Debug-Infos
    # Öffne einen Listening-Socket, über den Anwendungsprogramme den Proxy nutzen können
    listeningSocket = bindSocket(port_bypassi)
    # Fehlerbehandlung, beende Thread
    if listeningSocket == None :
        return
    threads = []
    while True :
        #print("Wait for new connection") # Debug-Infos
        # Warte am Listening-Socket auf eine Anwendung
        (ok, source) = acceptNewConnection(listeningSocket)
        # Fehlerbehandlung
        if ok == False :
            return
        else :
            if source != None :
                # Starte neuen Thread um die neue Verbindung zu behandeln
                thread = threading.Thread(target=dealWithConnection, args=(source, address_di, port_di, address_s, port_x, port_bypassi), daemon=True)
                thread.start()
                #print("Starting Thread") # Debug-Infos
                threads.append(thread)
        threads = removeFinishedThreads(threads)
        

# Sortiere Threads von beenden Verbindungen aus.
def removeFinishedThreads(threads) :
    newThreads = []
    for thread in threads :
        if not thread.is_alive() :
            thread.join()
            #print("Joining Thread") # Debug-Infos
        else :
            newThreads.append(thread)
    return newThreads

# Deals with new connections in a new thread
def dealWithConnection(source, address_di, port_di, address_s, port_x, port_bypassi) :
    #print("Connecting to Server") # Debug-Infos
    # Baue Verbindung zum Proxy-Server auf
    proxyServer = connectToProxyServer(address_s, port_x)
    # Fehlerbehandlung
    if proxyServer == None :
        source.close()
        return
    #print("Send Destination to Provy Server") # Debug-Infos
    # Sende die Informationen für den Zielserver an den Proxy-Server
    success = sendDestinationToServer(proxyServer, address_di, port_di)
    # Fehlerbehandlung
    if not success :
        source.close()
        proxyServer.close()
        return
    #print("New connection") # Debug-Infos
    # Starte das Tunneln der Daten
    tunnelingData(source, proxyServer)
    # Schließe die Verbindungen, falls Übertragung beendet
    source.close()
    proxyServer.close()
    
    

# Baue Verbindung zum Proxy-Server address:port auf.
def connectToProxyServer(address, port) :
    try :
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    except socket.error as errorMessage:
        print("Socket Error: %s" % errorMessage)
        sock.close()
        return None
    try :
        # Falls TLS genutzt werden soll, nutze den Socket-Wrapper von ssl
        if useTLS :
            sock = context.wrap_socket(sock, server_side=False, server_hostname=address)
        # Baue Verbidnung auf
        sock.connect((address, port))
    # Fehlerbehandlung
    except ssl.SSLError as errorMessage :
        print("Error verifying server: %s" % errorMessage)
        sock.close()
        return None
    except socket.error as errorMessage:
        print("Error connecting to Server: %s" % errorMessage)
        sock.close()
        return None
    return sock

# Sendet die Informationen für den Zielserver (address:port) and den Proxy-Server
def sendDestinationToServer(proxyServer, address, port) :
    # Erstelle die zu sendenden Daten
    data = struct.pack("!i", port) + address.encode()
    try :
        # Sende die Daten an den Proxy-Server
        proxyServer.sendall(data)
    # Fehlerbehandlung
    except socket.error as errorMessage :
        print("Error sending port_d and address_d to proxy server: %s" % errorMessage)
        return False
    # Empfange Antwort
    try :
        answer = proxyServer.recv(4)
    # Auswertung der Antwort
    except socket.error as errorMessage :
        print("Error receiving answer from proxy server: %s" % errorMessage)
        return False
    if len(answer.decode()) == 0 :
        print("Server probably had a problem with acl or could not connect to the address")
        return False
    if answer.decode() == "okay" :
        return True
    else :
        print("Unexpected answer from the proxy server")
        return False

# Binde einen Listening-Socket and den Port port und gib ihn zurück
def bindSocket(port) :
    try :
        listeningSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listeningSocket.bind(("localhost", port))
        listeningSocket.listen(1)
        # Set timeout to periodically join threads when waiting very long for a new connection
        listeningSocket.settimeout(60)
    except socket.error as errorMessage :
        print("Something went wrong when binding address: %s" % errorMessage)
        listeningSocket.close()
        return None
    return listeningSocket

# Warte beim Listening-Socket uf eine Anwendung, die sich mit dem Proxy verbinden will
def acceptNewConnection(listeningSocket) :    
    try :
        # Warte auf Verbindung
        (sock, _) = listeningSocket.accept()
    except socket.timeout :
        return (True, None)
    except socket.error as errorMessage :
        print("Error when accepting connection: %s" % errorMessage)
        listeningSocket.close()
        sock.close()
        return (False, None)
    # Gebe die neue Verbindung zurück
    return (True, sock)

# Tunnelt die Daten von source nach destination und umgekehrt
def tunnelingData(source, destination) :
    # Tunnelt die Daten bis Fehler/Verbindung unterbrochen
    while True :
        #print("Loop") # Debug-Infos
        # Eine Liste der zu überwachenden Sockets
        socketList = [source, destination]
        # Warte mit select bis Daten von einem der zu überwachenden Sockets gelesen werden können (dann müssen Daten weitergeleitet werden)
        # oder einer der zu überwachenden Server einen Fehler wirft.
        readSocket, writeSockets, errorSockets = select.select(socketList, [], socketList)
        # Falls ein Socket fehlerhaft ist, beende das Tunneln
        if len(errorSockets) > 0 :
            return
        
        # Für jeden Socket, von dem gelesen werden kann...
        for sock in readSocket :
            # Ordne die Sockets, von s1 wird gelesen, nach s2 wird weitergeleitet
            s1 = None
            s2 = None
            if sock == source :
                s1 = source
                s2 = destination
            else :
                s1 = destination
                s2 = source
            try :
                # Lese Daten von s1
                data = s1.recv(SIZE)
                # Falls die Verbindung beendet wurde, beende das Tunneln
                if (len(data) == 0) :
                    #print("Connection closed") # Debug-Infos
                    return
                else :
                    # Ansonsten: Sende die Daten nach s2
                    s2.sendall(data)
            # Fehlerbehandlung: Beende das Tunneln
            except ssl.SSLError as errorMessage :
                print("SSLError: %s" % errorMessage)
                return
            except socket.error as errorMessage :
                return

def cleanupAndExit() :
    sys.exit()

def signalHandler(s, f) :
    print("User quitting programm!")
    cleanupAndExit()

if __name__ == "__main__" :
    signal.signal(signal.SIGINT, signalHandler)
    # Verarbeite die Argumente
    dealWithArguments()
    # Lese die Konfigurationsdatei ein.
    configs = readConfigFile()
    # Führe für jeden Eintrag einen Thread aus.
    threads = [threading.Thread(target=clientInstance, args=(config,), daemon=True) for config in configs]
    for thread in threads :
        thread.start()
    for thread in threads :
        thread.join()
    print("Programm finished!")
