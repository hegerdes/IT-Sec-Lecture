import signal
import argparse
import threading
import struct
import socket
import sys
import select
import ssl

SIZE = 256 * 1024

threadPool = []

# Parst die Argumente


def dealWithArguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("-l", help="binding address")
    parser.add_argument("-p", help="listen-port")
    parser.add_argument(
        "--certificate", help="location of the certificate of the server")
    parser.add_argument(
        "--key", help="location of the private key of the server")
    parser.add_argument("--ca", help="Path to the certificate of the CA")
    parser.add_argument(
        "--acl", help="Path to a file with user names for authenticity")
    parser.add_argument("--socks", action="store_true",
                        help="use SOCKS protocoll, overrides all other arguments")
    args = parser.parse_args()

    address = args.l

    global pathToServerCertificate
    global pathToServerPrivateKey
    global useTLS
    global doClientAuth
    global useACL
    global acl
    global useSOCKS

    useSOCKS = args.socks

    # Falls SOCKS genutzt werden sollen (--socks), nutze nur die übergebene Addresse und den Port, ignoriere den Rest
    if useSOCKS:
        try:
            # Parse den Port zu int
            port = int(args.p)
        except ValueError:
            print("Port was not a number!")
            sys.exit()
        # Überprüfe den Port
        if (0 <= port and port <= 65535):
            return (address, port)
        else:
            print("Port not in expected range!")
            sys.exit()

    useTLS = False
    doClientAuth = False
    useACL = False
    acl = None

    pathToServerCertificate = args.certificate
    pathToServerPrivateKey = args.key
    pathToCACertificate = args.ca
    pathToACL = args.acl

    # Falls Zertifikat und private Key gesetzt sind, soll TLS genutzt werden.
    if (pathToServerCertificate != None and pathToServerPrivateKey != None):
        useTLS = True

    # Falls Zertifikat der CA übergeben wurde, soll der Client authentifiziert werdne.
    if (pathToCACertificate != None):
        doClientAuth = True

    # Falls eine ACL-Datei übergeben wurde, nutze ACL
    if (pathToACL != None):
        useACL = True
        try:
            # Ließ die ACL-Datei ein.
            aclFile = open(pathToACL, "r")
            acl = [name.strip() for name in aclFile.readlines()]
            aclFile.close()
        except:
            print("Reading ACL-File went wrong, quitting")
            aclFile.close()
            sys.exit()

    # Bereite TLS mit der ssl-library vor.
    global context
    context = None

    if useTLS:
        if doClientAuth:
            # Nutze ssl als Server
            context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
            # Client muss authentifiziert werden
            context.verify_mode = ssl.CERT_REQUIRED
            # Lade CA Zertifikat
            context.load_verify_locations(cafile=pathToCACertificate)
        else:
            # Nutze ssl als Server
            context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
            context.check_hostname = False
            # Deaktiviere Client-Verifikation
            context.verify_mode = ssl.CERT_NONE
        # Lade Zeritifkat und private Key des Servers für die Authentifizierung des Servers
        context.load_cert_chain(
            certfile=pathToServerCertificate, keyfile=pathToServerPrivateKey)

    try:
        # Parse den Port zu int
        port = int(args.p)
    except ValueError:
        print("Port was not a number!")
        sys.exit()

    # Überprüfe den Port
    if (0 <= port and port <= 65535):
        return (address, port)
    else:
        print("Port not in expected range!")
        sys.exit()

# Bereite einen Listening-Socket vor, speichere ihn als globale Variable


def prepareListeningSocket(address, port):
    global listeningSocket
    try:
        listeningSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listeningSocket.bind((address, port))
        listeningSocket.listen(1)
        # Set timeout to periodically join threads when waiting very long for a new connection
        listeningSocket.settimeout(60)
    except socket.error as errorMessage:
        print("Something went wrong when binding address: %s" % errorMessage)
        listeningSocket.close()
        sys.exit()

# Warte auf neue Verbindung


def listening():
    try:
        # Warte auf neue Verbindung
        (sock, _) = listeningSocket.accept()
    except socket.timeout:
        return None
    except socket.error as errorMessage:
        print("Acceping connection went wrong: %s" % errorMessage)
        cleanupAndExit()
    # Falls nicht im SOCKS-Modus und TLS genutzt werden soll
    if (not useSOCKS) and useTLS:
        try:
            # Wrappe den Socket in ssl-Wrapper der ssl-library
            sock = context.wrap_socket(sock, server_side=True)
        # Fehlerbehandlung (Verifikation des Client)
        except ssl.SSLError as errorMessage:
            print("Verification went wrong: %s" % errorMessage)
            sock.close()
            return None
        # Falls ACL genutzt werden soll, überprüfe ob der commonName aus dem Zertifikat des Clienten in der ACL-Datei steht
        if useACL:
            peerCertificate = sock.getpeercert()
            subject = dict(x[0] for x in peerCertificate['subject'])
            cn = subject['commonName']
            isIn = False
            for user in acl:
                if user == cn:
                    isIn = True
            if not isIn:
                print("Common Name not in ACL")
                sock.close()
                return None
    return sock

# Starte für neue Verbindungen jeweils einen eigenen Thread, der diese Verbindung behandelt


def dealingWithNewConnection(sock):
    if useSOCKS:
        # Falls SOCKS genutzt werden sollen...
        thread = threading.Thread(
            target=serverSOCKS, args=(sock,), daemon=True)
        thread.start()
        threadPool.append(thread)
    else:
        # Proxy aus Aufgabe 1 und 2
        thread = threading.Thread(target=serverFun, args=(sock,), daemon=True)
        thread.start()
        threadPool.append(thread)

# Thread-Funktion zur Behandlung der Verbindung im Nicht-SOCKS-Modus


def serverFun(source):
    # Empfange die Informationen zum Zielserver vom Client
    dest = getDestination(source)
    # Fehlerbehandlung
    if dest == None:
        return
    (address, port) = dest
    # Versuche eine Verbindung zum Zielserver aufzubauen
    destination = connectToDestination(address, port, source)
    # Fehlerbehandlung
    if destination == None:
        source.close()
        return
    # Wenn alle Verbindungen aufgebaut sind, tunnel die Daten
    tunnelingData(source, destination)
    # Baue die Verbindungen ab
    source.close()
    destination.close()

# Thread-Funkiton zur Behandlung der Verbindung im SOCKS-Modus


def serverSOCKS(source):
    # Empfange vom Client CONNECT- oder BIND-Request
    result = getFirstPackageAndParse(source)
    # Fehlerbehandlung
    if result == None:
        return
    (cd, port, address, ident) = result
    # Verarbeite den Request
    if (cd == 1):
        doCONNECT(source, port, address, ident)
    else:
        doBIND(source, port, address, ident)


def getFirstPackageAndParse(source):
    try:
        # Empfange das Request-Paket
        data = source.recv(SIZE)
    # Fehlerbehandlung beim Empfang
    except socket.error as errorMessage:
        print("Socks: Error receiving first package: %s" % errorMessage)
        source.close()
        return None
    # Falls Verbindung direkt beendet wurde
    if len(data) == 0:
        source.close()
        return None
    # Falls die empfangenen Daten kürzer sind als erwartet.
    if len(data) < 9:
        print("Socks: First Package was too short!")
        sendReply(source, 91, 42, "1.2.3.4")
        print(data)
        return None
    # Entpacke Version, Command, port und ip-Addresse
    (vn, cd, port, ip1, ip2, ip3, ip4) = struct.unpack("!BBHBBBB", data[0:8])
    # Speichere den Rest zwischen
    rest = data[8:]
    # Überprüfe ob Version und Command valide sind
    if (vn == 4) and (1 <= cd) and (cd <= 2):
        # Teile den Rest an Nullbytes in Teile
        restSplit = rest.split(b"\x00")
        # Falls die übertragene ip-Addresse verlangt, dass der Proxy-Server den Hostnamen auflösen muss
        if (ip1 == 0 and ip2 == 0 and ip3 == 0 and ip4 > 0):
            # Dann muss Rest in 3 Teile zerfallen, von denen der letzte Teil leer ist
            if (len(restSplit) == 3) and restSplit[2] == b"":
                # print("Socks-Debug: Got Non-IPv4-Address") # Debug-Infos
                try:
                    # An Stelle 1 sollte dann der aufzulösende Hostname sein
                    address = socket.gethostbyname(restSplit[1].decode())
                except socket.error as errorMessage:
                    # Im Fehlerfall, teile das dem Client mit, beende Verbindung
                    print("Socks: Error getting IP-Address of target: %s" %
                          errorMessage)
                    sendReply(source, 91, 42, "1.2.3.4")
                    source.close()
                    return None
                # Gib bei Erfolg alle Daten zurück
                return (cd, port, address, restSplit[0])
            else:
                # Fehlerbehandlung falls unpassend viele Teile und letzter Teil nicht b""
                # print("Socks: Rest was unexpected. Quitting") # Debug-Infos
                sendReply(source, 91, 42, "1.2.3.4")
                source.close()
                return None
        else:
            # Falls die ip-Addresse gültig ist, sollte der Rest in zwei Teile zerfallen, von denen der letzte leer ist.
            if (len(restSplit) == 2 and restSplit[1] == b""):
                # print("Socks-Debug: Got IPv4-Address") # Debug-Infos
                address = str(ip1) + "." + str(ip2) + "." + \
                    str(ip3) + "." + str(ip4)
                # Gebe die ausgelesenen Infos zurück
                return (cd, port, address, restSplit[0])
            else:
                # Falls fehlerhaft, teile das dem Client mit, beende Programm.
                print("Socks: Rest was unexpected. Quitting")
                sendReply(source, 91, 42, "1.2.3.4")
                source.close()
                return None
    else:
        print("Socks: Wrong data in first package.")
        sendReply(source, 91, 42, "1.2.3.4")
        source.close()
        return None

# Sendet eine Antwort auf das Request-Paket an den Client


def sendReply(source, cd, port, address):
    # Spalte Addresse auf + Check
    try:
        ipParts = [int(num) for num in address.split(".")]
    except ValueError:
        print("SOCKS: Error converting to IP-Address")
        return False
    if len(ipParts) != 4:
        print("Socks: Send reply with unexpected ip " + address)
        return False
    for part in ipParts:
        if (part < 0 or part > 255):
            print("Socks: Send reply with unexpected ip " + address)
            return False
    # Überprüfe Port
    if port < 0 or port > 65535:
        print("Socks: Send reply with wrong port " + str(port))
        return False
    try:
        # Zu sendende Daten
        data = struct.pack("!BBHBBBB", 0, cd, port,
                           ipParts[0], ipParts[1], ipParts[2], ipParts[3])
        # Sende Daten
        source.sendall(data)
    except socket.error as errorMessage:
        print("Socks: Sending reply went wrong: %s" % errorMessage)
        return False
    return True

# Funktion, die überprüft, ob der Zugriff gestattet werden soll. Wir erlauben jedem den Zugang, also gibt diese Funktion immer True zurück


def grantConnection(sourceIP, destIP, destPort, userID):
    return True

# Bearbeitet den CONNECT-Request


def doCONNECT(source, port, addressServer, ident):
    # print("Socks-Debug: Got CONNECT-Paket") # Debug-Infos
    # Bestimme ob Zugriff erlaubt werden soll.
    okay = grantConnection(source.getpeername(), addressServer, port, ident)
    if okay:
        # Falls ja, versuche Verbindung zum Zielserver aufzubauen
        try:
            destination = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # Setzt Timeout von 2 Minuten, siehe SOCKS-Referenz.
            destination.settimeout(120.0)
        # Fehlerbehandlung Socket
        except socket.error as errorMessage:
            print("Socks: Socket error: %s" % errorMessage)
            destination.close()
            sendReply(source, 91, port, addressServer)
            source.close()
            return
        returnValue = destination.connect_ex((addressServer, port))
        # Fehlerbehandlung connection
        if returnValue != 0:
            print("Socks: Connecting to destination went wrong")
            destination.close()
            sendReply(source, 91, port, addressServer)
            source.close()
            return
        else:
            # Erfolgsfall, teile dies dem Client mit, Tunnel die Daten, danach beende Verbindungen
            if not sendReply(source, 90, port, addressServer):
                source.close()
                destination.close()
                return
            tunnelingData(source, destination)
            source.close()
            destination.close()
            return
    else:
        # Falls Zugriff nicht erlaubt wurde.
        print("Socks: Connection not granted!")
        sendReply(source, 91, port, addressServer)
        source.close()
        return

# Behandelt den BIND-Request


def doBIND(source, port, addressServer, ident):
    # print("Socks-Debug: Got BIND-Paket") # Debug-Infos
    # Überprüfe ob Zugriff gewährt werden soll.
    okay = grantConnection(source.getpeername(), addressServer, port, ident)
    if okay:
        # Erstelle Listening-Socket für eingehende Verbindung
        try:
            lSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # Setze Timeout auf 2 Minuten, siehe SOCKS-Referenz
            lsock.settimeout(120.0)
            # Binde den Socket an einen freien Port
            lSock.bind((address, 0))
            lSock.listen(1)
            # Informiere den Client, dass eingehende Verbindungen
            if not sendReply(source, 90, lSock.getsockname()[1], address):
                source.close()
                lSock.close()
                return
        except socket.error as errorMessage:
            print("Socks: Something went wrong when binding address: %s" %
                  errorMessage)
            lSock.close()
            source.close()
            return
        try:
            # Warte auf eingehende Verbindung eingehende Verbindung
            (dest, destAddress) = lSock.accept()
            lSock.close()
        except socket.timeout:
            lSock.close()
            source.close()
            return
        except socket.error as errorMessage:
            print("Socks: Something went wrong when accepting connection: %s" %
                  errorMessage)
            lSock.close()
            source.close()
            return
        # Falls die eingehnde Verbindung nicht von dem Server stammt, der im BIND-Request angekündigt war.
        if destAddress != addressServer:
            # Teile mit, dass Fehler aufgetreten ist.
            sendReply(source, 91, port, addressServer)
            source.close()
            dest.close()
            return
        else:
            # Im Erfolgsfall, benachrichtige Client und Tunnel die Daten.
            if not sendReply(source, 90, dest.getsockname()[1], address):
                source.close()
                dest.close()
                return
            tunnelingData(source, dest)
            # Beende Verbindungen
            source.close()
            dest.close()
            return
    else:
        print("Socks: Connection not granted!")
        sendReply(source, 91, port, addressServer)
        source.close()
        return

# Empfange und Verarbeite die Informationen zum Zielserver


def getDestination(sock):
    try:
        received = sock.recv(SIZE)
    except socket.error as errorMessage:
        print("Receiving went wrong: %s" % errorMessage)
        sock.close()
        return None
    # Eine reguläre Anfrage besteht aus mehr als 4 Byte
    if (len(received) > 4):
        # Die ersten 4 Byte sind der Port
        (port,) = struct.unpack("!i", received[0:4])
        # Der Rest ist die Addresse
        address = received[4:].decode()
        # Überprüfe ob Port im gültigen Bereich
        if (0 <= port and port <= 65535):
            return (address, port)
        else:
            print("Received port number not in range")
            sock.close()
            return None
    else:
        print("Received destination was to short!")
        sock.close()
        return None

# Verbindet den Proxy-Server zum Zielserver (address:port) und sendet bei Erfolg Bestätigung an Client


def connectToDestination(address, port, source):
    try:
        destination = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    except socket.error as errorMessage:
        print("Socket error: %s" % errorMessage)
        destination.close()
        return None
    returnValue = destination.connect_ex((address, port))
    if returnValue != 0:
        print("Connecting to destination went wrong")
        destination.close()
        return None
    try:
        # Falls erfolgreich, sende Antwort and Client
        answer = "okay"
        source.sendall(answer.encode())
    except socket.error as errorMessage:
        print("Error sending answer: %s" % errorMessage)
        destination.close()
        return None
    return destination

# Tunnelt die Daten zwischen source und destination


def tunnelingData(source, destination):
    while True:
        # Liste der zu überwachenden Sockets
        socketList = [source, destination]
        # Es wird mit select auf Sockets gewartet, von den gelesen werden kann oder die Fehler haben
        readSocket, writeSockets, errorSockets = select.select(
            socketList, [], socketList)
        # Falls ein Fehler aufgetreten ist, beende das Tunneln
        if len(errorSockets) > 0:
            return

        # Gehe alle Sockets durch, von denen gelesen werden kann
        for sock in readSocket:
            # Ordne die Sockets, von s1 wird empfangen, nach s2 wird gesendet
            s1 = None
            s2 = None
            if sock == source:
                s1 = source
                s2 = destination
            else:
                s1 = destination
                s2 = source
            try:
                # Lese Daten von s1
                data = s1.recv(SIZE)
                # print("Data received") # Debug-Infos
                # Falls Verbindung beendet wurde, beende das Tunneln
                if (len(data) == 0):
                    # print("Connection closed") # Debug-Infos
                    return
                else:
                    # Ansonsten sende Daten nach s2 weiter
                    s2.sendall(data)
                    #print("Data send")
            # Fehlerbehandlung
            except ssl.SSLError as errorMessage:
                print("SSLError: %s" % errorMessage)
                return
            except socket.error as errorMessage:
                return

# Sortiere Threads von beenden Verbindungen aus.


def removeFinishedThreads():
    global threadPool
    threadpoolTemp = []
    for thread in threadPool:
        if not thread.is_alive():
            thread.join()
        else:
            threadpoolTemp.append(thread)
    threadPool = threadpoolTemp


def cleanupAndExit():
    listeningSocket.close()
    sys.exit()


def signalHandler(s, f):
    print("User quitting programm!")
    cleanupAndExit()


if __name__ == "__main__":
    signal.signal(signal.SIGINT, signalHandler)
    # Verarbeite die Argumente
    (address, port) = dealWithArguments()
    # Bereite Listening-Socket für eingehende Verbindungen vor
    prepareListeningSocket(address, port)

    while True:
        # Warte auf neue Verbindung
        newSocket = listening()
        # Falls erfolgreich, behandle die Verbindung in einem neuen Thread
        if (newSocket != None):
            dealingWithNewConnection(newSocket)
        # Sortiere die Threads der beendeten Verbindungen aus.
        removeFinishedThreads()
