import signal
import argparse
import threading
import os

# Parse die Argumente bezüglich der Vorgaben und speichere die Informationen in globalen Variablen
def dealWithArguments() :
    parser = argparse.ArgumentParser()
    parser.add_argument("-f", help="Path to the configuration file.")
    parser.add_argument("-u", help="User name for the ssh-connection.")
    args = parser.parse_args()
    
    global configFilePath
    configFilePath = args.f
    global userName
    userName = args.u

# Ließt die Konfigurationsdatei ein
def readConfigFile() :
    try :
        # Lese die Konfigurationsdatei ein und speichere sie Zeilenweise in einer Liste
        configFile = open(configFilePath, "r")
        lines = configFile.readlines()
        configFile.close()
    except :
        print("Error when reading configuration file, quitting programm!")
        configFile.close()
        sys.exit()
    # Entferne Leerzeichen vor und am Ende jeder Zeile
    linesTrimmed = [line.strip() for line in lines]
    # Filtere Kommentarzeilen und Leerzeilen aus.
    linesWithoutComments = [line for line in linesTrimmed if (line != "" and line[0] != "#")]
    # Parse die Einträge
    return map(parseConfig, linesWithoutComments)

# Parst die Einträge der Konfigurationsdatei
def parseConfig(config) :
    # Zerlege die Einträge am ":" und entferne Leerzeichen zu Beginn und am Ende jedes Teils
    listOfEntries = [s.strip() for s in config.split(":")]
    
    # Jeder Eintrag sollte aus genau 5 Teilen bestehen
    if len(listOfEntries) != 5 :
        print("Error in configuration file!")
        sys.exit()
    
    # Speichere die Teile entsprechend ihrer Bedeutung, versuche die Ports zu ints zu parsen.
    address_di = listOfEntries[0]
    address_s = listOfEntries[2]
    try :
        port_di = int(listOfEntries[1])
        port_x = int(listOfEntries[3])
        port_bypassi = int(listOfEntries[4])
    except :
        print("Error parsing ports in configuration file!")
        sys.exit()
    
    # Überprüfe die Ports auf zulässige Range
    if (0 <= port_di and port_di <= 65535 and 0 <= port_x and port_x <= 65535 and 0 <= port_bypassi and port_bypassi <= 65535) :
        return (address_di, port_di, address_s, port_x, port_bypassi)
    else :
        print("Some ports in the configuration file are not in a valid range")
        sys.exit()

# Funktion für die Threads
def clientInstance(config) :
    (address_di, port_di, address_s, port_x, port_bypassi) = config
    # Öffne eine ssh-Verbindung mit den Daten aus der Konfigurationsdatei
    sshCommand = "ssh -L " + str(port_bypassi) + ":" + address_di + ":" + str(port_di) + " " + str(userName) + "@" + address_s
    os.system(sshCommand)
    

def cleanupAndExit() :
    sys.exit()

def signalHandler(s, f) :
    print("User quitting programm!")
    cleanupAndExit()

if __name__ == "__main__" :
    signal.signal(signal.SIGINT, signalHandler)
    
    # Verarbeite die Argumente
    dealWithArguments()
    # Lese die Konfigurationsdatei ein
    configs = readConfigFile()
    # Führe für jeden Eintrag der Konfigurationsdatei einen eigenen Thread aus.
    threads = [threading.Thread(target=clientInstance, args=(config,), daemon=True) for config in configs]
    for thread in threads :
        thread.start()
    for thread in threads :
        thread.join()
    print("Programm finished!")
