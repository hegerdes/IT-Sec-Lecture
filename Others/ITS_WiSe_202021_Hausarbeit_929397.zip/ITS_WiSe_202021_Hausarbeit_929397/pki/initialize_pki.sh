#!/bin/bash


# Aufgabe 2.1

rm -rf certificates
rm -f ca.srl
mkdir certificates

# Erzeugt den private Key (ca.key) und das Zertifikat für die Root-CA (ca.pem)
# req ist das passende utility
# -x509: sorgt dafür, dass ein selbstsigniertes Zertifikat ausgegeben wird
# -nodes: der private Key soll nicht verschlüsselt sein
# -newkey rsa:2048: sorgt dafür, dass ein neuer private Key mit dem Algorithmus rsa und einer Länge von 2048 bit erzeugt wird.
# -keyout ...: Pfad + Dateiname, in dem der private key gespeichert werden soll.
# -sha256: Nutze sha256 als message digest
# -days 365: Das Zertifikat soll 1 Jahr gültig sein.
# -out ...: Pfad + Dateiname, in dem das Zertifikat gespeichert werden soll.
# -subj ...: Setzt das Subject-Feld auf den geforderten Wert (gefordert war nur der Common Name (CN) authority-929397)
openssl req -x509 -nodes -newkey rsa:2048 -keyout certificates/ca.key -sha256 -days 365 -out certificates/ca.pem -subj "/CN=authority-929397"

# Erzeugt den private key (example.key) und einen zugehörigen certificate signing request (example.csr)
# req: Das passende Utility
# -nodes: private key soll nicht verschlüsselt werden.
# -newkey rsa:2048: Es wird ein neuer private key erzeugt, dazu wird der Algorithmus rsa mit einer Schlüssellänge von 2048 bit genutzt.
# -keyout ...: Pfad + Dateiname, in dem der private Key gespeichert wird.
# -out ...: Pfad + Dateiname, in dem die certificate signing request gespeichert werden soll.
# subj ...: Setzt das Subject-Feld auf den geforderten Wert (Common Name example)
openssl req -nodes -newkey rsa:2048 -keyout certificates/example.key -out certificates/example.csr -subj "/CN=example"

# Erzeugt aus dem certificate signing request (example.csr) das mit dem private key der CA signierte Zertifikat
# x509: Ist das passende Utility
# -req: Die Eingabe ist ein certificate signing request
# -in ...: Pfad + Dateiname für die Eingabe (das csr)
# -CA ...: Pfad + Dateiname zum CA Zertifikat, das zum Signieren genutzt werden soll
# -CAkey ...: Pfad + Dateiname des private keys der CA
# -CAcreateserial: Erzeugt eine Datei für die CA Seriennummer, falls diese Datei noch nicht existiert
# -CAserial ...: PFad + Dateiname der Datei mit der CA Seriennummer (falls vorhanden, wird die dort gespeicherte Seriennummer genutzt, wenn nicht wird wegen -CAcreateserial diese Datei vorher erstellt). Die Seriennummer wird fürs Signieren verwendet und dann automatisch inkrementiert.
# -sha256: Nutze sha256 als message digest
# -days 365: Das Zertifikat soll 1 Jahr gültig sein.
# -out ...: Pfad + Dateiname für das zu speichernde signierte Zertifikat
openssl x509 -req -in certificates/example.csr -CA certificates/ca.pem -CAkey certificates/ca.key -CAcreateserial -CAserial ca.srl -sha256 -days 365 -out certificates/example.pem

# Aufgabe 2.2 und folgende (mit etwas weniger Kommentaren)

# private key für den server und csr erstellen
# -addext "subjectAltName=...": Fügt dem certifiate signing request die sinnvollen subject alternative names hinzu
openssl req -nodes -newkey rsa:2048 -keyout certificates/server.key -out certificates/server.csr -subj "/CN=server-929397" -addext "subjectAltName=IP:131.173.33.211,IP:131.173.33.209,DNS:bones.informatik.uni-osnabrueck.de,DNS:diggory.informatik.uni-osnabrueck.de,DNS:bones.informatik.uos.de,DNS:diggory.informatik.uos.de"


# public  von ca signieren, leider müssen die subject alternative names hier wiederholt angegeben werden
# -extfile <(printf ...): Fügt dem signierten Zertifikat die subject alternative names hinzu, leider habe ich keine Möglichkeit gefunden, dass
# diese aus dem certificate singing request übernommen wird. (Quelle: https://security.stackexchange.com/questions/74345/provide-subjectaltname-to-openssl-directly-on-the-command-line)
openssl x509 -req -in certificates/server.csr -CA certificates/ca.pem -CAkey certificates/ca.key -CAcreateserial -CAserial ca.srl -extfile <(printf "subjectAltName=IP:131.173.33.211,IP:131.173.33.209,DNS:bones.informatik.uni-osnabrueck.de,DNS:diggory.informatik.uni-osnabrueck.de,DNS:bones.informatik.uos.de,DNS:diggory.informatik.uos.de") -sha256 -days 365 -out certificates/server.pem

# Erzeuge private key und csr für client1
openssl req -nodes -newkey rsa:2048 -keyout certificates/client1.key -out certificates/client1.csr -subj "/CN=client1"

# Erzeuge von CA signiertes certificate für client1
openssl x509 -req -in certificates/client1.csr -CA certificates/ca.pem -CAkey certificates/ca.key -CAcreateserial -CAserial ca.srl -sha256 -days 365 -out certificates/client1.pem

# Erzeuge private key und csr für client1
openssl req -nodes -newkey rsa:2048 -keyout certificates/client2.key -out certificates/client2.csr -subj "/CN=client2"

# Erzeuge von CA signiertes certificate für client2
openssl x509 -req -in certificates/client2.csr -CA certificates/ca.pem -CAkey certificates/ca.key -CAcreateserial -CAserial ca.srl -sha256 -days 365 -out certificates/client2.pem


# Ein paar Zertifikate zum Testen

# Selbstsigniertes Server-Certificate (+ private key)
openssl req -x509 -sha256 -nodes -days 365 -newkey rsa:2048 -keyout certificates/server-WithoutCA.key -out certificates/server-WithoutCA.pem -subj "/CN=server-929397"

# Selbstsigniertes Client-Certificate (+ private key)
openssl req -x509 -sha256 -nodes -days 365 -newkey rsa:2048 -keyout certificates/client-WithoutCA.key -out certificates/client-WithoutCA.pem -subj "/CN=client1"

# Server certificate mit falschem hostname
openssl req -nodes -newkey rsa:2048 -keyout certificates/server-wrongname.key -out certificates/server-wrongname.csr -subj "/CN=server-929397" -addext "subjectAltName=DNS:example.org"

openssl x509 -req -in certificates/server-wrongname.csr -CA certificates/ca.pem -CAkey certificates/ca.key -CAcreateserial -CAserial ca.srl -extfile <(printf "subjectAltName=DNS:example.org") -sha256 -days 365 -out certificates/server-wrongname.pem
