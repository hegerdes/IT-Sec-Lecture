#!/bin/bash

rm -f ./evaluation/bonus/results/evaluation_bonus_unverschluesselt.pcap

sudo tcpdump -i eth0 -e -s 64 -w ./evaluation/bonus/results/evaluation_bonus_unverschluesselt.pcap host 131.173.33.211 &

python3 proxy_client.py -f ./evaluation/config1.txt &

sleep 5

echo "Teste unverschlüsselten Proxy"

./evaluation/bonus/ttfb_client localhost 2500 > ./evaluation/bonus/results/result_unverschluesselt.txt
echo "$(cat ./evaluation/bonus/results/result_unverschluesselt.txt)"

sleep 5

killall python3
sudo killall tcpdump
