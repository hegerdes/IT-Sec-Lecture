#!/bin/bash


rm -f ./evaluation/bonus/results/evaluation_bonus_mit_server_und_nutzer_auth_mit_acl.pcap

sudo tcpdump -i eth0 -e -s 64 -w ./evaluation/bonus/results/evaluation_bonus_mit_server_und_nutzer_auth_mit_acl.pcap host 131.173.33.211 &

python3 proxy_client.py -f ./evaluation/config4.txt --ca ./pki/certificates/ca.pem --certificate ./pki/certificates/client1.pem --key ./pki/certificates/client1.key &


sleep 5

echo "Teste Proxy mit Server und Nutzer Auth mit ACL"

./evaluation/bonus/ttfb_client localhost 2503 > ./evaluation/bonus/results/result_mit_server_und_nutzer_auth_mit_acl.txt
echo "$(cat ./evaluation/bonus/results/result_mit_server_und_nutzer_auth_mit_acl.txt)"

sleep 5

killall python3
sudo killall tcpdump
