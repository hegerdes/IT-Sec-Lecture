#!/bin/bash

mergecap -w ./evaluation/bonus/evaluation_bonus.pcap ./evaluation/bonus/results/evaluation_bonus_ohne_proxy.pcap ./evaluation/bonus/results/evaluation_bonus_unverschluesselt.pcap ./evaluation/bonus/results/evaluation_bonus_ohne_nutzer_auth.pcap ./evaluation/bonus/results/evaluation_bonus_mit_server_und_nutzer_auth.pcap ./evaluation/bonus/results/evaluation_bonus_mit_server_und_nutzer_auth_mit_acl.pcap
