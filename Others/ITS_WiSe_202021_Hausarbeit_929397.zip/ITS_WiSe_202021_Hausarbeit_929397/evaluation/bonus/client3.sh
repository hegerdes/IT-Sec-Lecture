#!/bin/bash


rm -f ./evaluation/bonus/results/evaluation_bonus_ohne_nutzer_auth.pcap

sudo tcpdump -i eth0 -e -s 64 -w ./evaluation/bonus/results/evaluation_bonus_ohne_nutzer_auth.pcap host 131.173.33.211 &


python3 proxy_client.py -f ./evaluation/config2.txt --ca ./pki/certificates/ca.pem &

sleep 5

echo "Teste Proxy ohne Nutzer-Auth"

./evaluation/bonus/ttfb_client localhost 2501 > ./evaluation/bonus/results/result_ohne_nutzer_auth.txt
echo "$(cat ./evaluation/bonus/results/result_ohne_nutzer_auth.txt)"

sleep 5


killall python3
sudo killall tcpdump
