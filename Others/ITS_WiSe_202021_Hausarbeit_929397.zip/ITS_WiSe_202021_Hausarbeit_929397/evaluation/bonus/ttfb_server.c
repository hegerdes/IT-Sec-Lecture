#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
/* Simple TTFB Test Server.
Compile with gcc -o ttfb_server ttfb_server.c
run with ./ttfb_server port_to_listen
Accepts (a single) TCP connection on the specified port
Tries to send an ASCII 'P' (nonblocking), and closes the connection.
*/
int main(int argc, char** argv){
    if (argc != 2) {
        fprintf(stderr,"usage: %s port_to_listen\n",argv[0]);
        exit(1);
    }
    int listen_socket;
    int opt = 1;
    struct sockaddr_in serveraddr;
    struct sockaddr_in clientaddr;
    listen_socket=socket(AF_INET, SOCK_STREAM, 0);
    if(listen_socket<0){
        fprintf(stderr, "Error in creating socket\n");
        exit(1);
    }
    memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serveraddr.sin_port = htons(atoi(argv[1]));
    setsockopt(listen_socket, SOL_SOCKET, SO_REUSEADDR, &opt , sizeof(int));
    
    if(bind(listen_socket,(const struct sockaddr*)&serveraddr, sizeof(serveraddr))<0){
        fprintf(stderr, "Error in binding socket\n");
        exit(1);
    }
    if(listen(listen_socket, 20)<0){
        fprintf(stderr, "Error in Listening\n");
        exit(1);
    }
    while(1){
        socklen_t clientlen;
        int con_sock = accept(listen_socket, (struct sockaddr *) &clientaddr, &clientlen);
        if(con_sock<0){
            fprintf(stderr, "Error in accept\n");
            exit(1);
        }
        fcntl(con_sock, F_SETFL, O_NONBLOCK);
        write(con_sock, "P", 1);
        close(con_sock);
    }
}
