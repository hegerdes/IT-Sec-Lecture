#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#include <time.h>

/* Simple TTFB Test Client.
Compile with gcc -o ttfb_client ttfb_client.c
run with ./ttfb_client hostname port
Connects 100 times (sequentially) to the given TCP server, and receives one byte.
If the first byte is an ASCII 'P', continues.
If the first byte is any other char or nothing is received, tries again (and does not count this connection the 100 times)
*/
int main(int argc, char** argv) {
    if (argc != 3) {
        fprintf(stderr,"usage: %s hostname port\n",argv[0]);
        exit(1);
    }
    
    int num = 1000;
    time_t before, after;
    
    //TODO: Start time measurement
    before = time(NULL);
    
    for(int i=0;i<num;i++){
        int tcp_socket;  
        char buf[1];
        struct sockaddr_in server_addr;
        struct hostent *host;

        host=gethostbyname(argv[1]);
        if(host<=0) {
            fprintf(stderr, "Could not get IP\n");
            exit(1);
        }
        tcp_socket=socket(AF_INET, SOCK_STREAM, 0);
        if(tcp_socket<=0) {
            fprintf(stderr, "Could not open socket\n");
            exit(1);
        }

        memset(&server_addr, 0, sizeof(struct sockaddr_in));
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(atoi(argv[2]));
        server_addr.sin_addr = *((struct in_addr *)host->h_addr);

        if (connect(tcp_socket, (struct sockaddr *)&server_addr, sizeof(struct sockaddr_in))<0) {
            fprintf(stderr, "Could not open connect\n");
            exit(1);
        }
        
        int bytes_received=recv(tcp_socket, buf, 1, 0);
        if (bytes_received <0) {
                perror("recv");
                exit(1);
        }

        if(bytes_received!=1 || buf[0]!='P'){
            i=(i>0?i-1:i);
        }

        close(tcp_socket);
    }
    //TODO: Stop time measurement and output (divided by 100)
    after = time(NULL);
    
    int diff = after - before;
    double mean = (double) diff / (double) num;
    
    printf("Laufzeit: %d, mittlere Laufzeit einer Schleife: %f\n", diff, mean);
    
    return 0;
}
