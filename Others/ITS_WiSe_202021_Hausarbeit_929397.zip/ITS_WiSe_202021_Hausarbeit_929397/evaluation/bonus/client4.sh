#!/bin/bash


rm -f ./evaluation/bonus/results/evaluation_bonus_mit_server_und_nutzer_auth.pcap

sudo tcpdump -i eth0 -e -s 64 -w ./evaluation/bonus/results/evaluation_bonus_mit_server_und_nutzer_auth.pcap host 131.173.33.211 &

python3 proxy_client.py -f ./evaluation/config3.txt --ca ./pki/certificates/ca.pem --certificate ./pki/certificates/client1.pem --key ./pki/certificates/client1.key &


sleep 5

echo "Teste Proxy mit Server und Nutzer Auth"

./evaluation/bonus/ttfb_client localhost 2502 > ./evaluation/bonus/results/result_mit_server_und_nutzer_auth.txt
echo "$(cat ./evaluation/bonus/results/result_mit_server_und_nutzer_auth.txt)"

sleep 5

killall python3
sudo killall tcpdump
