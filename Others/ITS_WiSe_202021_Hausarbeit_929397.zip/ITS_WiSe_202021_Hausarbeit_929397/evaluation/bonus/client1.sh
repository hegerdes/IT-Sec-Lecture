#!/bin/bash

rm -f ./evaluation/bonus/results/evaluation_bonus_ohne_proxy.pcap

sudo tcpdump -i eth0 -e -s 64 -w ./evaluation/bonus/results/evaluation_bonus_ohne_proxy.pcap host 131.173.33.211 &

sleep 5

echo "Teste ohne Proxy"

./evaluation/bonus/ttfb_client 131.173.33.211 1237 > ./evaluation/bonus/results/result_ohne_proxy.txt
echo "$(cat ./evaluation/bonus/results/result_ohne_proxy.txt)"

sleep 5

sudo killall tcpdump
