#!/bin/bash

rm -f ./evaluation/results/*.txt

python3 proxy_server.py -l bones.informatik.uos.de -p 2237 &

python3 proxy_server.py -l bones.informatik.uos.de -p 3237 --certificate ./pki/certificates/server.pem --key ./pki/certificates/server.key &

python3 proxy_server.py -l bones.informatik.uos.de -p 4237 --certificate ./pki/certificates/server.pem --key ./pki/certificates/server.key --ca ./pki/certificates/ca.pem &

python3 proxy_server.py -l bones.informatik.uos.de -p 5237 --certificate ./pki/certificates/server.pem --key ./pki/certificates/server.key --ca ./pki/certificates/ca.pem --acl ./acl.txt &

iperf -p 1237 -s > ./evaluation/results/server_output.txt
