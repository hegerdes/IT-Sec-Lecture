#!/bin/bash

rm -f ./evaluation/results/*.txt
rm -f ./evaluation/evaluation.pcap

sudo tcpdump -i eth0 -e -s 64 -w ./evaluation/evaluation.pcap host 131.173.33.211 &

python3 proxy_client.py -f ./evaluation/config1.txt &

python3 proxy_client.py -f ./evaluation/config2.txt --ca ./pki/certificates/ca.pem &

python3 proxy_client.py -f ./evaluation/config3.txt --ca ./pki/certificates/ca.pem --certificate ./pki/certificates/client1.pem --key ./pki/certificates/client1.key &

python3 proxy_client.py -f ./evaluation/config4.txt --ca ./pki/certificates/ca.pem --certificate ./pki/certificates/client1.pem --key ./pki/certificates/client1.key &

sleep 5

echo "Teste ohne Proxy"

iperf -p 1237 -c bones.informatik.uos.de -t 120 > ./evaluation/results/result_ohne_proxy.txt
echo "$(cat ./evaluation/results/result_ohne_proxy.txt)"

sleep 10

echo "Teste unverschlüsselten Proxy"

iperf -p 2500 -c localhost -t 120 > ./evaluation/results/result_unverschluesselt.txt
echo "$(cat ./evaluation/results/result_unverschluesselt.txt)"

sleep 10

echo "Teste Proxy ohne Nutzer-Auth"

iperf -p 2501 -c localhost -t 120 > ./evaluation/results/result_ohne_nutzer_auth.txt
echo "$(cat ./evaluation/results/result_ohne_nutzer_auth.txt)"

sleep 10

echo "Teste Proxy mit Server und Nutzer Auth"

iperf -p 2502 -c localhost -t 120 > ./evaluation/results/result_mit_server_und_nutzer_auth.txt
echo "$(cat ./evaluation/results/result_mit_server_und_nutzer_auth.txt)"

sleep 10

echo "Teste Proxy mit Server und Nutzer Auth mit ACL"

iperf -p 2503 -c localhost -t 120 > ./evaluation/results/result_mit_server_und_nutzer_auth_mit_acl.txt
echo "$(cat ./evaluation/results/result_mit_server_und_nutzer_auth_mit_acl.txt)"

sleep 10

sudo killall tcpdump
killall python3
